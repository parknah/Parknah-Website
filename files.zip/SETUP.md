# Parknah – Setup-Anleitung

## 🆕🆕 Buchungssystem einrichten (Stufe 2: Nutzerkonten + Buchungsanfragen)

Das ist der größte Umbau bisher. Führt der Reihe nach aus:

**1. E-Mail-Bestätigung für neue Nutzerkonten deaktivieren (für die Testphase)**

Geht in Supabase zu "Authentication" → "Sign In / Providers" → "Email" und
schaltet "Confirm email" aus. Sonst müssten neue Nutzer:innen erst eine
Bestätigungsmail anklicken, bevor sie sich einloggen können – für die
Testphase unnötige Hürde. (Später vor dem "scharfen" Go-Live wieder anschalten.)

**2. Datenbank erweitern**

Im SQL-Editor ausführen:

```sql
-- Jeder Stellplatz gehört jetzt einem eingeloggten Nutzerkonto
alter table listings add column owner_id uuid references auth.users(id);

-- Alte, offene Eintragen-Regel ersetzen: jetzt nur eingeloggt möglich
drop policy "Öffentliches Eintragen" on listings;
create policy "Eintragen nur eingeloggt"
  on listings for insert
  with check (auth.uid() = owner_id);

-- Neue Tabelle für Buchungsanfragen
create table bookings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  listing_id uuid not null references listings(id) on delete cascade,
  requester_id uuid not null references auth.users(id),
  requester_email text not null,
  start_date date not null,
  end_date date not null,
  status text not null default 'angefragt'
);

alter table bookings enable row level security;

create policy "Eigene Buchungen lesen (Anfragende)"
  on bookings for select
  using (auth.uid() = requester_id);

create policy "Buchungen für eigene Stellplätze lesen (Anbietende)"
  on bookings for select
  using (exists (
    select 1 from listings
    where listings.id = bookings.listing_id and listings.owner_id = auth.uid()
  ));

create policy "Buchung anfragen"
  on bookings for insert
  with check (auth.uid() = requester_id);

create policy "Status ändern nur Anbietende"
  on bookings for update
  using (exists (
    select 1 from listings
    where listings.id = bookings.listing_id and listings.owner_id = auth.uid()
  ));

-- Öffentliche, anonyme Funktion: zeigt NUR belegte Zeiträume eines
-- Stellplatzes (kein Name, keine E-Mail) – wird für die Verfügbarkeitsprüfung
-- beim Buchen gebraucht, ohne private Buchungsdaten offenzulegen
create or replace function get_booked_ranges(p_listing_id uuid)
returns table(start_date date, end_date date)
language sql
security definer
set search_path = public
as $$
  select start_date, end_date from bookings
  where listing_id = p_listing_id and status = 'bestaetigt';
$$;

grant execute on function get_booked_ranges(uuid) to anon, authenticated;
```

**3. Danach wie gewohnt:** `index.html`, `admin.html` und die neue Datei
`konto.html` bei GitHub hochladen.

---

## 🆕 Das müsst ihr jetzt neu ergänzen

Ihr habt die Grundeinrichtung (Supabase-Projekt, Tabellen, GitHub,
Cloudflare, Admin-Login) schon erledigt. Seit der letzten Version sind
folgende Dinge dazugekommen, die noch fehlen:

**1. Datenbank umstellen: Flughafen raus, Koordinaten (Karte) rein**

Im Supabase SQL-Editor ausführen:

```sql
alter table listings add column lat double precision;
alter table listings add column lng double precision;
alter table listings drop column if exists airport;

-- Öffentliche Lese-Berechtigung um lat/lng erweitern (Kontaktdaten bleiben gesperrt)
revoke select on listings from anon;
grant select (id, created_at, name, location, lat, lng, price, availability, description)
  on listings to anon;
```

**2. Karte & Adresssuche**

Läuft komplett kostenlos über OpenStreetMap (Leaflet) – kein Google-Konto,
keine Kreditkarte, kein API-Key nötig. Ist im Code schon fertig
eingebaut, ihr müsst hier nichts weiter einrichten.

Kleiner Hinweis: Der kostenlose Adresssuche-Dienst (Nominatim) bittet
darum, ihn nicht exzessiv zu nutzen – für eure Besucherzahlen in der
Testphase ist das aber kein Thema.

**3. Neue Datenbank-Berechtigung für "Bearbeiten" im Admin-Bereich**

Falls noch nicht geschehen, im Supabase SQL-Editor ausführen:

```sql
create policy "Bearbeiten nur für Admins"
  on listings for update
  using (auth.role() = 'authenticated');
```

**4. Formspree einrichten, damit "Interesse melden" euch eine E-Mail schickt**

Falls noch nicht geschehen:

1. Auf https://formspree.io kostenlos registrieren (mit info.parknah@gmail.com)
2. Neues Formular erstellen, Ziel-E-Mail: info.parknah@gmail.com
3. Formspree zeigt eine URL wie `https://formspree.io/f/abcdwxyz` – der Teil nach `/f/` ist eure Formular-ID
4. In `index.html` nach `FORMSPREE_FORM_ID` suchen und eintragen

**Danach wie gewohnt:** `index.html` und `admin.html` bei GitHub hochladen
(überschreiben die bestehenden Dateien) – Cloudflare deployt automatisch neu.

---

## 📖 Referenz: komplette Ersteinrichtung (bereits erledigt)

Der Rest dieser Datei ist eure ursprüngliche Schritt-für-Schritt-Anleitung
zum Nachschlagen, falls mal etwas unklar ist – müsst ihr nicht erneut
durchgehen.

## Schritt 1: Supabase-Projekt anlegen (kostenlos)

1. Geht auf https://supabase.com und meldet euch kostenlos an (z. B. mit GitHub).
2. Erstellt ein neues Projekt (Name z. B. "parknah", Region z. B. Frankfurt).
3. Wartet, bis das Projekt fertig eingerichtet ist (dauert ca. 1–2 Minuten).

## Schritt 2: Tabelle für die Stellplätze anlegen

1. Öffnet im Supabase-Dashboard den "SQL Editor" (linkes Menü).
2. Fügt folgendes SQL ein und klickt auf "Run":

```sql
create table listings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  name text not null,
  contact text not null,
  airport text not null,
  location text not null,
  price numeric not null,
  availability text not null,
  description text
);

alter table listings enable row level security;

create policy "Öffentliches Lesen"
  on listings for select
  using (true);

create policy "Öffentliches Eintragen"
  on listings for insert
  with check (true);

create policy "Löschen nur für Admins"
  on listings for delete
  using (auth.role() = 'authenticated');

create policy "Bearbeiten nur für Admins"
  on listings for update
  using (auth.role() = 'authenticated');

create table waitlist (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  name text not null,
  email text not null,
  interest text not null
);

alter table waitlist enable row level security;

create policy "Öffentliches Eintragen (Warteliste)"
  on waitlist for insert
  with check (true);

create policy "Lesen nur für Admins"
  on waitlist for select
  using (auth.role() = 'authenticated');

create policy "Löschen nur für Admins (Warteliste)"
  on waitlist for delete
  using (auth.role() = 'authenticated');
```

Hinweis: Die "listings"-Tabelle darf weiterhin von allen gelesen werden
(das ist die öffentliche Angebotsliste). Die "waitlist"-Tabelle enthält
E-Mail-Adressen und darf daher nur von euch (eingeloggt) gelesen werden.

## Schritt 2.5: Kontaktdaten vor der Öffentlichkeit schützen

Damit E-Mail/Telefonnummer aus dem "Stellplatz eintragen"-Formular
wirklich nur für euch (eingeloggte Admins) sichtbar sind – und nicht
zufällig über die öffentliche Schnittstelle abgreifbar sind – führt
im SQL-Editor zusätzlich aus:

```sql
revoke select on listings from anon;
grant select (id, created_at, name, airport, location, price, availability, description)
  on listings to anon;
```

Das erlaubt der Website (öffentliche Besucher), nur die aufgelisteten
Spalten zu lesen – die Spalte `contact` bleibt für alle außer
eingeloggten Admins gesperrt, direkt auf Datenbank-Ebene.

## Schritt 3: API-Zugangsdaten eintragen

1. Geht im Supabase-Dashboard zu "Project Settings" -> "API".
2. Kopiert die "Project URL" und den "anon public" Key.
3. Öffnet `index.html` und tragt beide Werte ein:

```js
const SUPABASE_URL = "https://xxxxx.supabase.co";
const SUPABASE_ANON_KEY = "eyJ...";
```

## Schritt 3.5: Admin-Zugang einrichten

Damit ihr euch in `admin.html` einloggen könnt, braucht ihr einen echten
Nutzer-Account in Supabase (nicht euren Supabase-Login selbst, sondern
einen separaten "App-Nutzer"):

1. Geht im Supabase-Dashboard zu **"Authentication"** → **"Users"**.
2. Klickt auf **"Add user"** → **"Create new user"**.
3. Vergebt eine E-Mail-Adresse und ein Passwort für euren Admin-Zugang
   (kann z. B. eure eigene E-Mail sein). Häkchen bei "Auto Confirm User"
   setzen, damit ihr euch sofort einloggen könnt.
4. Mit genau diesen Zugangsdaten könnt ihr euch später in `admin.html`
   einloggen.

Wichtig: Jede Person mit diesem Login kann Einträge löschen. Gebt das
Passwort nur an Personen weiter, die das auch dürfen sollen.

## Schritt 3.7: E-Mail-Benachrichtigung für "Interesse melden" einrichten

Damit ihr eine echte E-Mail bekommt, wenn jemand bei einem Stellplatz
auf "Interesse melden" klickt:

1. Geht auf https://formspree.io und meldet euch kostenlos an
   (mit info.parknah@gmail.com).
2. Erstellt ein neues Formular ("New Form"), als Ziel-E-Mail
   info.parknah@gmail.com eintragen (bzw. ist es automatisch, wenn ihr
   euch damit registriert habt).
3. Formspree zeigt euch eine Endpoint-URL wie
   `https://formspree.io/f/abcdwxyz`. Der Teil nach `/f/` ist eure
   Formular-ID.
4. Öffnet `index.html`, sucht nach `FORMSPREE_FORM_ID` und tragt die ID ein:

```js
const FORMSPREE_FORM_ID = "abcdwxyz";
```

Der kostenlose Formspree-Plan reicht für bis zu 50 Anfragen im Monat –
für die Testphase völlig ausreichend.

## Schritt 4: Code auf GitHub hochladen

1. Erstellt ein neues Repository auf https://github.com (z. B. "parknah-website").
2. Ladet die Dateien `index.html` **und `admin.html`** dort hoch (per
   Weboberfläche: "Add file" -> "Upload files", oder per Git, falls ihr
   das schon nutzt).
3. Euer Admin-Bereich ist danach unter `eure-adresse.dev/admin.html`
   erreichbar.

## Schritt 5: Kostenlos hosten (Cloudflare Pages)

1. Geht auf https://pages.cloudflare.com und meldet euch kostenlos an.
2. "Create a project" -> "Connect to Git" -> euer GitHub-Repository auswählen.
3. Build-Einstellungen könnt ihr leer lassen (keine Build-Schritte nötig,
   da es eine reine HTML-Datei ist).
4. Deployen – ihr bekommt eine kostenlose Adresse wie
   `parknah-website.pages.dev`.

Alternativ funktioniert genauso gut: Vercel (https://vercel.com) oder
GitHub Pages – alle drei sind für dieses Projekt kostenlos.

## Schritt 6 (später): Eigene Domain verbinden

Sobald ihr parknah.de gekauft habt, könnt ihr sie in Cloudflare Pages
unter "Custom domains" hinzufügen. Das dauert wenige Minuten und
erfordert keine Änderung am Code.

## Wichtig vor dem echten Live-Gang

Im Code sind im Impressum/Datenschutz noch Platzhalter markiert
(gelb hinterlegt), die **gesetzlich zwingend** ausgefüllt werden müssen
(Adresse, E-Mail). Ohne vollständiges Impressum ist eine deutsche
Website rechtlich angreifbar – das solltet ihr vor dem "scharfen"
Go-Live noch ergänzen.
